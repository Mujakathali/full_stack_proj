package com.example.loginregister.model;

public enum Role {
    ADMIN,
    DEV,
    USER
}
