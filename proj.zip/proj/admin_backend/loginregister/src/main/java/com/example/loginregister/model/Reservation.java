package com.example.loginregister.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.util.List;

@Entity
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Staff name is required")
    private String staffName;

    @NotBlank(message = "Event details are required")
    private String eventDetails;

    @NotBlank(message = "Date is required")
    private String selectedDate;

    @ElementCollection
    private List<String> selectedSlots;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getEventDetails() {
        return eventDetails;
    }

    public void setEventDetails(String eventDetails) {
        this.eventDetails = eventDetails;
    }

    public String getSelectedDate() {
        return selectedDate;
    }

    public void setSelectedDate(String selectedDate) {
        this.selectedDate = selectedDate;
    }

    public List<String> getSelectedSlots() {
        return selectedSlots;
    }

    public void setSelectedSlots(List<String> selectedSlots) {
        this.selectedSlots = selectedSlots;
    }

    // Constructors
    public Reservation(Long id, String staffName, String eventDetails, String selectedDate, List<String> selectedSlots) {
        this.id = id;
        this.staffName = staffName;
        this.eventDetails = eventDetails;
        this.selectedDate = selectedDate;
        this.selectedSlots = selectedSlots;
    }

    public Reservation() {
    }
}
