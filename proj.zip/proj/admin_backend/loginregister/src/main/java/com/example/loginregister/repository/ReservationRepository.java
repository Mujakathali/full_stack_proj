package com.example.loginregister.repository;

import com.example.loginregister.model.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {
   
        List<Reservation> findByStaffName(String staffName);
    // Custom query method to find reservations by staff name (or any other condition)
    
        List<Reservation> findByUserEmail(String userEmail);
    
    List<Reservation> findAll();
}
