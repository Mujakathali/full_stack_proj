package com.example.hall_booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HallBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
