package com.example.hall_booking.enums;

public enum Role {
    USER,
    ADMIN,
    DEV
}
