package com.example.hall_booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HallBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HallBookingApplication.class, args);
	}

}
