import React, { useState, useEffect } from 'react';
import './ps.css'; // Custom styling
import axios from 'axios';

const BookingSummary = () => {
  const [bookings, setBookings] = useState([]);
  const [activeBooking, setActiveBooking] = useState(null);
  const [cancelConfirmation, setCancelConfirmation] = useState(false);
  const [cancelBookingId, setCancelBookingId] = useState(null);

  // Fetch bookings when the component mounts
  useEffect(() => {
    const userEmail = localStorage.getItem('userEmail');  // Assuming email is stored in localStorage

    const fetchBookings = async () => {
      if (userEmail) {
        try {
          const response = await axios.get(`http://localhost:8082/api/v1/reservations/user/${userEmail}`);
          setBookings(response.data);  // Store the fetched bookings in state
        } catch (error) {
          console.error('Error fetching bookings:', error);
        }
      }
    };

    fetchBookings();  // Fetch bookings for the logged-in user
  }, []); // Re-fetch bookings every time the component mounts

  // Function to add a new booking directly to the state
  const addNewBooking = (newBooking) => {
    setBookings((prevBookings) => [...prevBookings, newBooking]);
  };

  const handleBookingClick = (id) => {
    setActiveBooking(activeBooking === id ? null : id);  // Toggle active state
  };

  const handleCancelClick = (booking) => {
    const currentTime = new Date();
    const bookingTime = new Date(booking.bookingTime);
    const timeDiff = (currentTime - bookingTime) / 1000; // Time difference in seconds

    if (timeDiff <= 600) {
      setCancelBookingId(booking.id);
      setCancelConfirmation(true);  // Show confirmation dialog
    } else {
      alert("Cancellation window has expired!");
    }
  };

  const confirmCancel = async () => {
    try {
      await axios.delete(`http://localhost:8082/api/v1/reservations/${cancelBookingId}`);
      alert('Booking cancelled successfully');
      setCancelConfirmation(false);
      // Remove the booking from the list after cancellation
      setBookings((prevBookings) => prevBookings.filter((booking) => booking.id !== cancelBookingId));
    } catch (error) {
      console.error('Error cancelling booking:', error);
    }
  };

  const rejectCancel = () => {
    setCancelConfirmation(false);  // Close the cancel confirmation dialog
  };

  return (
    <div className="booking-summary-container">
      {bookings.length > 0 ? (
        bookings.map((booking) => (
          <div
            key={booking.id}
            className={`booking-summary-row ${activeBooking === booking.id ? 'active' : ''}`}
            onClick={() => handleBookingClick(booking.id)}
          >
            <h2>{booking.staffName}</h2>
            <p className="p">
              <span>Assigned By: {booking.assignedBy || 'N/A'}</span>
              <span className="end-date">Start Date: {booking.selectedDate || 'N/A'}</span>
            </p>

            {activeBooking === booking.id && (
              <div className="booking-summary-details">
                <div className="booking-summary-description">
                  <span>Description:</span> {booking.eventDetails || 'No description available'}
                </div>
                <div className="booking-summary-slot">
                  <span>Slot:</span> {booking.selectedSlots.join(', ') || 'N/A'}
                </div>
                <button
                  className="cancel-button"
                  onClick={(e) => {
                    e.stopPropagation();  // Prevent toggling details when clicking cancel
                    handleCancelClick(booking);
                  }}
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        ))
      ) : (
        <p>No bookings available</p>
      )}

      {cancelConfirmation && (
        <div className="cancel-confirmation-modal">
          <p>Are you sure you want to cancel this booking?</p>
          <button
            className="confirm-button"
            onClick={confirmCancel}
          >
            Yes
          </button>
          <button className="cancel-button" onClick={rejectCancel}>
            No
          </button>
        </div>
      )}
    </div>
  );
};

export default BookingSummary;
