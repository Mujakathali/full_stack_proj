import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import "./p.css"; // Assuming the styles are in the same folder

const BookingForm = () => {
  const location = useLocation();  // Get the location (state) passed from ProductList
  const [staffName, setStaffName] = useState("");
  const [eventDetails, setEventDetails] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedSlots, setSelectedSlots] = useState([]);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const navigate = useNavigate();

  // Modify the timeSlots array to show slots from 9:30 AM to 7:30 PM
  const timeSlots = [
    { label: "09:30 AM - 10:30 AM", startHour: 9, startMinute: 30 },
    { label: "10:30 AM - 11:30 AM", startHour: 10, startMinute: 30 },
    { label: "11:30 AM - 12:30 PM", startHour: 11, startMinute: 30 },
    { label: "12:30 PM - 01:30 PM", startHour: 12, startMinute: 30 },
    { label: "01:30 PM - 02:30 PM", startHour: 13, startMinute: 30 },
    { label: "02:30 PM - 03:30 PM", startHour: 14, startMinute: 30 },
    { label: "03:30 PM - 04:30 PM", startHour: 15, startMinute: 30 },
    { label: "04:30 PM - 05:30 PM", startHour: 16, startMinute: 30 },
    { label: "05:30 PM - 06:30 PM", startHour: 17, startMinute: 30 },
    { label: "06:30 PM - 07:30 PM", startHour: 18, startMinute: 30 },
  ];

  const today = new Date().toISOString().split("T")[0];

  const isPastSlot = (slot) => {
    const now = new Date();
    return (
      now.getHours() > slot.startHour ||
      (now.getHours() === slot.startHour && now.getMinutes() > slot.startMinute)
    );
  };

  const filteredTimeSlots =
    selectedDate === today
      ? timeSlots.filter((slot) => !isPastSlot(slot))
      : timeSlots;

  const handleSlotToggle = (slotLabel) => {
    if (selectedSlots.includes(slotLabel)) {
      setSelectedSlots(selectedSlots.filter((slot) => slot !== slotLabel));
    } else {
      setSelectedSlots([...selectedSlots, slotLabel]);
    }
  };

  const handleSelectAllSlots = () => {
    setSelectedSlots(filteredTimeSlots.map((slot) => slot.label));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!staffName || !eventDetails || selectedSlots.length === 0 || !selectedDate) {
      setError("Please fill in all required fields.");
      return;
    }

    setError("");

    const bookingData = {
      staffName,
      eventDetails,
      selectedDate,
      selectedSlots,
    };

    try {
      const response = await axios.post(
        "http://localhost:8082/api/v1/reservations",
        bookingData
      );

      setSuccess("Booking submitted successfully!");
      localStorage.setItem("userEmail", staffName); // Store email in localStorage

      // Redirect to booking-summary page after booking is submitted successfully
      setTimeout(() => {
        navigate("/booking-summary");
      }, 2000); // Redirect after 2 seconds to show success message
    } catch (error) {
      setError("Failed to submit booking. Please try again.");
    }
  };

  return (
    <div className="bookingForm">
      <h2>Book a Seminar Hall</h2>

      {success && <div className="successMessage">{success}</div>}
      {error && <div className="errorMessage">{error}</div>}

      <form onSubmit={handleSubmit}>
        <div>
          <label>Lab Name</label>
          <input
            type="text"
            value={location.state?.labName} // Display the lab name
            readOnly  // Make it read-only
            className="labNameInput"  // You can apply custom styling to this if needed
          />
        </div>

        <div>
          <label>Staff Name</label>
          <input
            type="text"
            value={staffName}
            onChange={(e) => setStaffName(e.target.value)}
            required
          />
        </div>

        <div>
          <label>Event Details</label>
          <input
            type="text"
            value={eventDetails}
            onChange={(e) => setEventDetails(e.target.value)}
            required
          />
        </div>

        <div>
          <label>Select Date</label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            min={today}
            required
          />
        </div>

        <div>
          <label>Select Slots</label>
          <div>
            <button type="button" onClick={handleSelectAllSlots}>
              Select All
            </button>
          </div>
          <div className="timeSlots">
            {filteredTimeSlots.map((slot) => (
              <button
                type="button"
                key={slot.label}
                className={`timeSlot ${
                  selectedSlots.includes(slot.label) ? "selected" : ""
                }`}
                onClick={() => handleSlotToggle(slot.label)}
              >
                {slot.label}
              </button>
            ))}
          </div>
        </div>

        <button type="submit" className="submitButton">
          Submit Booking
        </button>
      </form>
    </div>
  );
};

export default BookingForm;
