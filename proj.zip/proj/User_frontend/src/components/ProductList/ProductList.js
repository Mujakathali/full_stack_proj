import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import oneBedRoom from "../../assets/Drawing hall.jpg";
import twoBedRoom from "../../assets/ES Seminar.jpg";
import bestOfferRoom1 from "../../assets/Pg Seminar.jpg";
import image1 from "../../assets/Zoho Lab.jpg";
import image2 from "../../assets/sf1.jpg";
import image3 from "../../assets/sf2.jpg";
import image4 from "../../assets/sf3.jpg";
import image5 from "../../assets/vankatramhall.jpg";
import image6 from "../../assets/Zoho Lab.jpg";

const ProductList = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const staticProducts = [
      {
        id: 1,
        name: "ES Seminar hall",
        image: oneBedRoom,
      },
      {
        id: 2,
        name: "PG Seminar Hall",
        image: twoBedRoom,
      },
      {
        id: 3,
        name: "SF1",
        image: bestOfferRoom1,
      },
      {
        id: 4,
        name: "SF2",
        image: image1,
      },
      {
        id: 5,
        name: "SF3",
        image: image2,
      },
      {
        id: 6,
        name: "Drawing Hall",
        image: image3,
      },
      {
        id: 7,
        name: "ES Drawing hall",
        image: image4,
      },
      {
        id: 8,
        name: "Venkatram HAll",
        image: image5,
      },
      {
        id: 9,
        name: "Zoho Lab",
        image: image6,
      },
    ];
    setProducts(staticProducts);
  }, []);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Available Halls</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) => (
          <div
            key={product.id}
            className="bg-white rounded-lg shadow-md overflow-hidden"
          >
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
              <div className="flex justify-between items-center">
                <Link
                  to="/booking"
                  state={{ labName: product.name }} // Passing the lab name as state
                  className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300"
                >
                  Book Now
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductList;
