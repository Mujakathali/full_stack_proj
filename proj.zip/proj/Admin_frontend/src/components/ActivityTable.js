import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableRow, Paper, Box, Typography, TableContainer } from '@mui/material';
import axios from 'axios';

const HallTable = () => {
  const [reservations, setReservations] = useState([]);  // Renamed from bookings to reservations
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchReservations = async () => {
      try {
        // Fetch all reservations from the backend (no email filter)
        const response = await axios.get('http://localhost:8082/api/v1/reservations');  // Adjusted API endpoint
        console.log('Reservations fetched:', response.data); // Log the data for debugging
        setReservations(response.data);  // Set the fetched reservations to state
      } catch (error) {
        console.error('Error fetching data:', error.message || error); // Log detailed error message
        setError('Failed to fetch reservations');
      }
    };

    fetchReservations();
  }, []);  // Empty dependency array to fetch once on component mount

  return (
    <TableContainer 
      component={Paper} 
      sx={{ mt: 3, maxHeight: '400px', overflowY: 'auto' }} // Set maxHeight and overflow
    >
      <Box p={2}>
        <Typography variant="h6">All Reservations</Typography>
        {error && <Typography color="error">{error}</Typography>}
      </Box>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Staff Name</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Event Details</TableCell>
            <TableCell>Date</TableCell>
            <TableCell>Time Slots</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {reservations.length > 0 ? (
            reservations.map((reservation) => (
              <TableRow key={reservation.id}>
                <TableCell>{reservation.staffName}</TableCell>
                <TableCell>{reservation.status || 'Pending'}</TableCell>  {/* Assuming status is part of the API response */}
                <TableCell>{reservation.eventDetails || 'N/A'}</TableCell>
                <TableCell>{reservation.selectedDate}</TableCell>
                <TableCell>{reservation.selectedSlots.join(', ') || 'N/A'}</TableCell> {/* Join selected slots if multiple */}
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={5}>No reservations found</TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default HallTable;
