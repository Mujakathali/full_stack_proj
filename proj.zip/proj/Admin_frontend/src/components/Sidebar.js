import React, { useState } from 'react';
import { Drawer, List, ListItem, ListItemIcon, ListItemText, Box, Typography, Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';
import { Home, People, BarChart, InsertChart, Description, MeetingRoom, Assessment } from '@mui/icons-material';
import { Link, useNavigate } from 'react-router-dom';
import logo from './logo.png';

const drawerWidth = 200;

const Sidebar = () => {
  const [openDialog, setOpenDialog] = useState(false); // State to control dialog visibility
  const [isLoggedIn, setIsLoggedIn] = useState(true); // Manage login state
  const navigate = useNavigate(); // React Router hook to navigate to login page

  // Function to handle logout button click
  const handleLogout = () => {
    setOpenDialog(true); // Open the confirmation dialog
  };

  // Function to confirm logout
  const handleConfirmLogout = () => {
    setIsLoggedIn(false); // Update login state
    setOpenDialog(false); // Close the dialog
    navigate('/login'); // Navigate to login page after logout confirmation
  };

  // Function to cancel logout
  const handleCancelLogout = () => {
    setOpenDialog(false); // Close the dialog without logging out
  };

  if (!isLoggedIn) {
    return null; // Do not render the sidebar if not logged in
  }

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: drawerWidth,
        '& .MuiDrawer-paper': {
          width: drawerWidth,
          backgroundColor: '#fdfdfd',
        },
      }}
    >
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mt: 2 }}>
        <img src={logo} alt="Logo" style={{ width: '200px', height: 'auto' }} />
        <Typography variant="h6">Hall Booking</Typography>
      </Box>
      <List>
        <ListItem button component={Link} to="/">
          <ListItemIcon><Assessment /></ListItemIcon>
          <ListItemText primary="Dashboard" />
        </ListItem>
        <ListItem button component={Link} to="/halls">
          <ListItemIcon><MeetingRoom /></ListItemIcon>
          <ListItemText primary="Halls" />
        </ListItem>
        <ListItem button component={Link} to="/users">
          <ListItemIcon><People /></ListItemIcon>
          <ListItemText primary="Users" />
        </ListItem>
        <ListItem button component={Link} to="/report">
          <ListItemIcon><Description /></ListItemIcon>
          <ListItemText primary="Report" />
        </ListItem>
      </List>
      
      {/* Logout Button */}
      <Box sx={{ marginTop: 'auto', paddingBottom: 2, textAlign: 'center' }}>
        <Button variant="contained" color="error" onClick={handleLogout}>
          Logout
        </Button>
      </Box>

      {/* Confirmation Dialog */}
      <Dialog open={openDialog} onClose={handleCancelLogout}>
        <DialogTitle>Confirm Logout</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to logout?</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCancelLogout} color="primary">
            Cancel
          </Button>
          <Button onClick={handleConfirmLogout} color="primary">
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </Drawer>
  );
};

export default Sidebar;
