// Login.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';
import logo from './logo.png';

function Login({ setIsAuthenticated }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    // Check if the credentials match
    if (email === 'Admin@123' && password === 'Admin123') {
      setIsAuthenticated(true); // Set user as authenticated
      navigate('/'); // Redirect to the main page
    } else {
      setErrorMessage('Invalid username or password.');
    }
  };

  return (
    <div className="login-container">
      <div className="app-details">
        <img src={logo} alt="logo" className="application-logo" />
        <p className="description">Experience Seamless Elegance in Event Spaces.</p>
      </div>
      <div className="credentials">
        <div className="login-form-container">
          <form id="login-form" onSubmit={handleSubmit}>

            <div className="input-container">
              <input
                type="text"
                name="email"
                id="email"
                placeholder="Email or phone number"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div className="input-container">
              <input
                type="password"
                name="password"
                id="password"
                placeholder="Password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <div className="submit-button">
              <button type="submit">Login</button>
            </div>
          </form>

          {errorMessage && <p className="error-message">{errorMessage}</p>}
        </div>
      </div>
    </div>
  );
}

export default Login;
